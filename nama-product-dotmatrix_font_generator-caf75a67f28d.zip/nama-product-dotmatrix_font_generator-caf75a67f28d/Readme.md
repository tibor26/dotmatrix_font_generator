# M1 Dot Matrix Font Generator
Python scripts to generate C code tables of font data from an Excel file.

# Usage
`python font.py font_5x6.xlsx > font.c`

Then copy the content of `font.c` to M1 `Core/font.c` (replace only the font data).